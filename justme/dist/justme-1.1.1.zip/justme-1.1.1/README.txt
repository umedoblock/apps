Prohibit to run two process/instance at same time.
To use a transaction behavior via sqlite3.

For example it is convinience to below case.

sqlite3 の transaction 機能を使うことで、
同時に２つ以上のprocessが起動しないように出来ます。
例えば、 以下のような場合に役に立ちます。

1. CGI script.
2. GUI application.

NOTICE:
There is no cracking resistence.

注意:
craking 対策は何もしていません。
