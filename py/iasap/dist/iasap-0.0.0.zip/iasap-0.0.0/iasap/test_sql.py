# Copyright 2011-2015 梅濁酒(umedoblock)

import unittest

from sql import *
print(dir())

class TestSQL(unittest.TestCase):
    def test_sql(self):
        pass

if __name__ == '__main__':
    unittest.main()
