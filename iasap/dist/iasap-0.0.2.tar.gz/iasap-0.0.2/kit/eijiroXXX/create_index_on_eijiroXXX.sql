-- Copyright 2011-2015 梅濁酒(umedoblock)

/* index
-- CREATE INDEX index_name ON table_name(field_name);
-- CREATE INDEX index_name ON table_name(field_name COLLATE NOCASE);
*/
CREATE  INDEX index_key
        ON eijiroXXX(key COLLATE NOCASE);
CREATE  INDEX index_value
        ON eijiroXXX(value COLLATE NOCASE);
